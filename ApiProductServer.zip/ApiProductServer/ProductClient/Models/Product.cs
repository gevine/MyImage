﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProductClient.Models
{
    public class Product
    {   [Key]
    [Display(Name ="Mã Mặt Hàng")]
        public int productId { get; set; }
        [Display(Name ="Tên Mặt Hàng")]
        [StringLength(50,ErrorMessage ="Tên mặt hàng trong khoảng từ 5 đến 50 ký tự")]
        [Required(ErrorMessage ="{0} không được để trống")]
        public string productName { get; set; }
        [Required(ErrorMessage = "{0} không được để trống")]
        [DataType(DataType.Currency)]
        [Display(Name = "Giá")]
        [Range(1,5000,ErrorMessage ="Giá trong khoảng 1 đển 5000")]
        public Nullable<int> price { get; set; }
        public string catName { get; set; }
    }
}