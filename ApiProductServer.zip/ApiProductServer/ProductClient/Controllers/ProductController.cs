﻿using Newtonsoft.Json;
using ProductClient.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace ProductClient.Controllers
{
    public class ProductController : Controller
    {
        private const string baseUri = "http://localhost:58115/api/Product";
        // GET: Product
        public ActionResult Index()
        {
            var client = new HttpClient();
            var response = client.GetStringAsync(baseUri);
            var productlist = JsonConvert.DeserializeObject<List<Product>>(response.Result);
            client.Dispose();//xoa biến client 
            return View(productlist);
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Product product)
        {
            if(ModelState.IsValid)
            {
                var client = new HttpClient();
                var response = client.PostAsJsonAsync(baseUri, product).Result;
                if(response.IsSuccessStatusCode)
                {
                    ViewBag.Message = "Insert product success!!!";
                }
                client.Dispose();
                return RedirectToAction("Index");
            }
            return View();
        }
        //Edit:Get
        public ActionResult Edit(int id)
        {
            var client = new HttpClient();
            var response = client.GetAsync(baseUri + "/" + id).Result;
            if(!response.IsSuccessStatusCode)
            {
                return View();
            }
            var product = response.Content.ReadAsAsync(typeof(Product)).Result;
            return View(product);
        }
        //Edit :Post
        [HttpPost]
        public ActionResult Edit(Product product)
        {
            if (ModelState.IsValid)
            {
                var client = new HttpClient();
                var response = client.PutAsJsonAsync(baseUri + "/" + product.productId, product).Result;
                if (response.IsSuccessStatusCode)
                {
                    ViewBag.Message = "Update product success!!";

                }
                client.Dispose();
                return View();
               
            }
            return RedirectToAction("Index");
        }
        //ham delete
        public ActionResult Delete(int id)
        {
            var client = new HttpClient();
            var response = client.DeleteAsync(baseUri + "/" + id).Result;
            if(response.IsSuccessStatusCode)
            {
                ViewBag.Message = "Delete product success!!";
            }
            return RedirectToAction("Index");
        }
       

    }
}