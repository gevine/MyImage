﻿using ApiProductServer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace ApiProductServer.Controllers
{
    public class ProductController : ApiController
    {
        ProductDAL dal = new ProductDAL();
        public IList<Product> GetProducts()//lấy hết product có trong database
        {
            return dal.Products;
        }
        //lấy product theo Id
        [ResponseType(typeof(Product))]
        public IHttpActionResult GetProduct(int id)
        {
            Product p = dal.Products.SingleOrDefault(pp => pp.productId == id);
            if(p==null)
            {
                return NotFound();
            }
            return Ok(p);
        }
        //-----------------hết hàm GetProduct by Id ------------------------------------
        //hàm Update ----------------------
        public IHttpActionResult Put(int id, Product product)
        {
            dal.Update(id, product);
            return StatusCode(HttpStatusCode.OK);
        }
        //-------------Hết hàm Update --------------------------------------------------
        //hàm Insert product -----------------------------------------------------------
        [ResponseType(typeof(Product))]
        public IHttpActionResult PostProduct(Product product)
        {
            if(ModelState.IsValid)
            {
                dal.Create(product);
            }
            return StatusCode(HttpStatusCode.OK);
        }
        //hàm Delete -----------------------------------------
        public IHttpActionResult Delete(int id)
        {
            dal.Delete(id);
            return StatusCode(HttpStatusCode.OK);
        }

    }
}
