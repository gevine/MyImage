﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApiProductServer.Models
{
    public class ProductDAL
    {
        ProductManagementEntities db;
        public ProductDAL()
        {
            db = new ProductManagementEntities();
        }
        //--------- khai báo 1 Property để lấy dữ liệu -----------------
        public List<Product> Products
        {
            get
            {
                return db.Products.ToList();
            }
        }
        //-----------------------------------------------------------
        //hàm Create Product
        public bool Create(Product product)
        {
            Product p = db.Products.SingleOrDefault(pp => pp.productId == product.productId);
            if(p==null) //chưa có product này
            {
                db.Products.Add(product);//thì đưa vào
                db.SaveChanges(); // lưu xuống database
                return true;
            }
            return false;
        }
        //----------------hết hàm Create ---------------------------------------------
        //hàm Update -----------------------------------------------------------------
        public bool Update(int id,Product product)
        {
            db.Entry(product).State = System.Data.Entity.EntityState.Modified;
            return db.SaveChanges() > 0;
        }
        //-----------hết hàm Update ---------------------------------------------------
        //hàm Delete ------------------------------------------------------------------
        public bool Delete(int id)
        {
            //tìm đối tượng muốn xóa dựa vào Id
            Product delproduct = db.Products.SingleOrDefault(p => p.productId == id);
            if(delproduct!=null) //Tìm thấy
            {
                db.Products.Remove(delproduct); //tiến hành xóa nó
                db.SaveChanges(); //lưu xuống database
                return true;
            }
            return false;
        }
        //-------------------Hết hàm Delete -------------------------------------------------

    }
}